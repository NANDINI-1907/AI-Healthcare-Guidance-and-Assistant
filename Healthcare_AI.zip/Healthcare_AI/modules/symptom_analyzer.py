import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier


# =====================================================
# LOAD DATASET
# =====================================================

data = pd.read_csv(
    "data/symptoms.csv"
)


# =====================================================
# SYMPTOMS USED BY THE MODEL
# =====================================================

symptoms = [
    "fever",
    "cough",
    "sore_throat",
    "headache",
    "runny_nose",
    "fatigue",
    "stomach_pain",
    "vomiting",
    "diarrhea"
]


# =====================================================
# INPUT DATA
# =====================================================

X = data[symptoms]


# =====================================================
# ENCODE CONDITIONS
# =====================================================

encoder = LabelEncoder()

y = encoder.fit_transform(
    data["condition"]
)


# =====================================================
# CREATE MODEL
# =====================================================

model = DecisionTreeClassifier(
    random_state=42
)


# =====================================================
# TRAIN MODEL
# =====================================================

model.fit(
    X,
    y
)


# =====================================================
# ANALYZE SYMPTOMS
# =====================================================

def analyze_symptoms(user_symptoms):

    user_symptoms = user_symptoms.lower()

    input_data = []

    for symptom in symptoms:

        readable_name = symptom.replace(
            "_",
            " "
        )

        if readable_name in user_symptoms:

            input_data.append(1)

        else:

            input_data.append(0)


    prediction = model.predict(
        [input_data]
    )[0]


    condition = encoder.inverse_transform(
        [prediction]
    )[0]


    return str(condition)